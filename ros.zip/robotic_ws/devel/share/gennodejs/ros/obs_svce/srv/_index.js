
"use strict";

let svce_eg = require('./svce_eg.js')

module.exports = {
  svce_eg: svce_eg,
};
